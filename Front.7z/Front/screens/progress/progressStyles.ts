// screens/progress/progressStyles.ts
import { StyleSheet, Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    alignItems: 'center',
    paddingTop: 20,
  },
  scrollContainer: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 15, // Adiciona padding horizontal para os cards não colarem nas bordas
  },
  logo: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  mainTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 25,
    textAlign: 'center',
  },
  chartCard: {
    backgroundColor: '#1C1C1E',
    borderRadius: 15,
    paddingVertical: 15, // Padding vertical dentro do card
    paddingHorizontal: 5,  // Menor padding horizontal para o gráfico caber melhor
    width: '100%', // O card ocupa toda a largura disponível (considerando o padding do scrollContainer)
    marginBottom: 25,
    alignItems: 'center', // Centraliza o título do gráfico
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  chartStyle: {
    marginVertical: 8,
    borderRadius: 16,
  },
  // Estilos adicionais para a legenda ou eixos, se necessário
});