// screens/plans/subscriptionPlansStyles.ts
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    alignItems: 'center',
    paddingTop: 20,
    paddingHorizontal: 20,
  },
  scrollContainer: {
    width: '100%',
    alignItems: 'center',
  },
  logo: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  mainTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 30,
    textAlign: 'center',
  },
  planCard: {
    backgroundColor: '#1C1C1E', // Cinza escuro para o card
    borderRadius: 15,
    padding: 20,
    width: '100%',
    marginBottom: 25,
    borderWidth: 1,
    borderColor: '#333333',
  },
  planTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 15,
    textAlign: 'center',
  },
  goldTitle: {
    color: '#FFD700', // Cor dourada para o plano gold
  },
  featureList: {
    marginBottom: 20,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  featureIcon: { // Para o emoji de check
    fontSize: 18,
    marginRight: 10,
  },
  featureText: {
    fontSize: 16,
    color: '#E0E0E0',
    flexShrink: 1,
  },
  priceText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 20,
  },
  actionButton: {
    backgroundColor: '#FFA500', // Laranja
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#000000',
    fontSize: 18,
    fontWeight: 'bold',
  },
  currentPlanButton: {
    backgroundColor: '#333333', // Cinza mais escuro para plano atual
  },
  currentPlanButtonText: {
    color: '#FFFFFF',
  },
  badge: {
    backgroundColor: '#FFA500',
    color: '#000000',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 5,
    overflow: 'hidden', // Para o borderRadius funcionar bem no Text
    position: 'absolute',
    top: -10,
    right: -10,
    transform: [{ rotate: '15deg' }],
  }
});