// screens/plans/SubscriptionPlansScreen.tsx
import React from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { styles } from './subscriptionPlansStyles';

const logoImage = require('../../assets/images/logo_branca_simples.png'); // Ajuste o caminho

const SubscriptionPlansScreen: React.FC = () => {
  const router = useRouter();

  // Simular qual é o plano atual do usuário (pode vir de um estado global/contexto)
  // 👇 CORREÇÃO AQUI 👇
  const currentUserPlan: 'free' | 'gold' = 'free';

  const handleSelectPlan = (planName: string) => {
    // Convertendo ambos para minúsculas para uma comparação mais robusta
    if (planName.toLowerCase() === currentUserPlan.toLowerCase()) {
      Alert.alert("Plano Atual", `Você já está no ${planName}.`);
    } else if (planName === "Plano Gold") {
      Alert.alert("Plano Gold", "Implementar lógica de assinatura para o Plano Gold.");
      // Aqui você navegaria para uma tela de pagamento ou iniciaria um fluxo de compra
    } else {
       Alert.alert("Plano Free", "Você escolheu continuar com o Plano Free.");
    }
  };

  const freePlanFeatures = [
    "Crie até 4 rotinas de treino diferentes",
    "Gere treinos com IA (pedidos ilimitados)",
    "Acompanhamento de progressão de carga",
  ];

  const goldPlanFeatures = [
    "Todos os benefícios do Plano Free",
    "Criação ilimitada de rotinas de treino",
    "Estatísticas avançadas de progresso",
    "Suporte prioritário",
    // Adicione mais features exclusivas aqui
  ];

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <Image source={logoImage} style={styles.logo} />
        <Text style={styles.mainTitle}>Nossos Planos</Text>

        {/* Card Plano Free */}
        <View style={styles.planCard}>
          <Text style={styles.planTitle}>Plano Free</Text>
          <View style={styles.featureList}>
            {freePlanFeatures.map((feature, index) => (
              <View key={`free-${index}`} style={styles.featureItem}>
                <Text style={styles.featureIcon}>✅</Text>
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>
          <TouchableOpacity
            style={[
              styles.actionButton,
              currentUserPlan === 'free' && styles.currentPlanButton
            ]}
            onPress={() => handleSelectPlan('Plano Free')}
            disabled={currentUserPlan === 'free'}
          >
            <Text style={[
              styles.actionButtonText,
              currentUserPlan === 'free' && styles.currentPlanButtonText
            ]}>
              {currentUserPlan === 'free' ? 'Seu Plano Atual' : 'Continuar com Free'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Card Plano Gold */}
        <View style={[styles.planCard, {borderColor: '#FFD700'}]}>
          <Text style={[styles.planTitle, styles.goldTitle]}>Plano Gold</Text>
          {/* <Text style={styles.badge}>POPULAR</Text> */}
          <View style={styles.featureList}>
            {goldPlanFeatures.map((feature, index) => (
              <View key={`gold-${index}`} style={styles.featureItem}>
                <Text style={styles.featureIcon}>🌟</Text>
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>
          <Text style={styles.priceText}>R$ 29,90 / mês</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handleSelectPlan('Plano Gold')}
            // Se você quiser desabilitar o botão do plano gold se ele for o atual:
            // disabled={currentUserPlan === 'gold'}
          >
            <Text style={styles.actionButtonText}>
              {currentUserPlan === 'gold' ? 'Seu Plano Atual' : 'Assinar Plano Gold'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default SubscriptionPlansScreen;