// screens/settings/settingsStyles.ts
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000', // Fundo preto
    alignItems: 'center',
    paddingTop: 20,
  },
  scrollContainer: {
    width: '100%',
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
    marginBottom: 20,
    // tintColor: '#FFFFFF', // Se for uma imagem que pode ser tingida
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 30,
  },
  settingsItem: {
    backgroundColor: '#2C2C2E', // Um cinza escuro para os itens
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 20,
    width: '90%',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  iconText: { // Para os emojis ou ícones de texto
    fontSize: 20,
    marginRight: 15,
    color: '#FFFFFF', // Cor padrão para emojis/ícones de texto
  },
  settingsItemText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  logoutButton: {
    // backgroundColor: '#2C2C2E', // Pode ter um fundo ou não
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 20,
    width: '90%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Centraliza o conteúdo do botão de logout
    marginTop: 20, // Espaço antes do botão de logout
    marginBottom: 30, // Espaço na parte inferior
  },
  logoutButtonText: {
    color: '#FF3B30', // Vermelho para logout
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10, // Se houver ícone
  },
});