// screens/settings/SettingsScreen.tsx
import React from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { styles } from './settingsStyle';
// Para ícones reais, você usaria: import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

// Substitua pela sua logo
const logoImage = require('@/assets/images/logo.png'); // Ajuste o caminho

interface SettingsItemProps {
  icon: string; // Emoji ou nome do ícone
  text: string;
  onPress: () => void;
  isLogout?: boolean; // Para estilização especial do botão de logout
}

const SettingsItem: React.FC<SettingsItemProps> = ({ icon, text, onPress, isLogout }) => {
  return (
    <TouchableOpacity
      style={isLogout ? styles.logoutButton : styles.settingsItem}
      onPress={onPress}>
      <Text style={styles.iconText}>{icon}</Text>
      <Text style={isLogout ? styles.logoutButtonText : styles.settingsItemText}>
        {text}
      </Text>
    </TouchableOpacity>
  );
};

const SettingsScreen: React.FC = () => {
  const router = useRouter();

  const settingsOptions = [
    { icon: '✏️', text: 'Editar Perfil', action: () => Alert.alert('Editar Perfil', 'Navegar para a tela de edição de perfil.') },
    { icon: '🎯', text: 'Metas de Treino', action: () => Alert.alert('Metas de Treino', 'Abrir configurações de metas.') },
    { icon: '⏰', text: 'Notificações', action: () => Alert.alert('Notificações', 'Abrir configurações de notificação.') },
    { icon: '🐦', text: 'Preferências de Treino', action: () => Alert.alert('Preferências de Treino', 'Definir preferências.') },
    { icon: '🌙', text: 'Tema (Claro/Escuro)', action: () => Alert.alert('Tema', 'Alternar tema do app.') },
    { icon: '📲', text: 'Conectar com apps de saúde', action: () => Alert.alert('Apps de Saúde', 'Conectar com Google Fit/Apple Health.') },
    { icon: '🔐', text: 'Alterar Senha', action: () => Alert.alert('Alterar Senha', 'Navegar para alterar senha.') },
    { icon: '📜', text: 'Termos de Uso e Política de Privacidade', action: () => Alert.alert('Termos', 'Mostrar termos e política.') },
  ];

  const handleLogout = () => {
    Alert.alert(
      'Sair da Conta',
      'Você tem certeza que deseja sair?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Sair', style: 'destructive', onPress: () => {
            console.log('Usuário deslogado');
            router.replace('./index'); 
          }
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <Image source={logoImage} style={styles.logo} />
        <Text style={styles.title}>CONFIGURAÇÕES</Text>

        {settingsOptions.map((item, index) => (
          <SettingsItem
            key={index}
            icon={item.icon}
            text={item.text}
            onPress={item.action}
          />
        ))}

        <SettingsItem
          icon="🚪"
          text="Sair da Conta (Logout)"
          onPress={handleLogout}
          isLogout // Prop para aplicar estilo diferente
        />
      </ScrollView>
    </View>
  );
};

export default SettingsScreen;