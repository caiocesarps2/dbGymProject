import React from 'react';
import LoginScreen from '../screens/login/LoginScreen'; // Ajuste o caminho se necessário

const App = () => {
  return <LoginScreen />;
};

export default App; // Opcional, mas bom para consistência