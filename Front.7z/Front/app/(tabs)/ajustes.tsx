import SettingsScreen from '@/screens/settings/SettingsScreen'; 

export default SettingsScreen;