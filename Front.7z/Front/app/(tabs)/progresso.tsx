// app/(tabs)/progresso.tsx
import ProgressScreen from '@/screens/progress/progressScreen'; // Ajuste o caminho!
// Se `screens` está na raiz: import ProgressScreen from '../../screens/progress/ProgressScreen';
// Ou com alias: import ProgressScreen from '@/screens/progress/ProgressScreen';

export default ProgressScreen;