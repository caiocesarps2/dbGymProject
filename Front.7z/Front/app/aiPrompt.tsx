import AiPromptScreen from '@/screens/ai/AiPromptScreen';

export default AiPromptScreen;