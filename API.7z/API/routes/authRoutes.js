// routes/authRoutes.js
const express = require('express');
const router = express.Router();
const { registerUser } = require('../controllers/authController'); // Importa a função do controller

// Rota para POST /api/auth/register
router.post('/register', registerUser);

// A rota de login virá aqui depois

module.exports = router;