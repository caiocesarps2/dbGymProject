// controllers/authController.js
const User = require('../models/User'); // Importa o modelo User
const bcrypt = require('bcryptjs');

// Função para registrar um novo usuário
exports.registerUser = async (req, res) => {
  try {
    // 1. Obter os dados do corpo da requisição
    const { username, email, password, age, weight, height, goal, availability } = req.body;

    // 2. Validar se os campos obrigatórios (username, email, password) foram enviados
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'Por favor, forneça nome de usuário, email e senha.' });
    }

    // 3. Verificar se o usuário (email ou username) já existe
    const existingUserByEmail = await User.findOne({ email });
    if (existingUserByEmail) {
      return res.status(400).json({ message: 'Este email já está em uso.' });
    }
    const existingUserByUsername = await User.findOne({ username });
    if (existingUserByUsername) {
      return res.status(400).json({ message: 'Este nome de usuário já está em uso.' });
    }

    // 4. Hashear a senha
    const salt = await bcrypt.genSalt(10); // Gera um "salt" para o hash
    const hashedPassword = await bcrypt.hash(password, salt); // Cria o hash da senha

    // 5. Criar o novo usuário
    const newUser = new User({
      username,
      email,
      password: hashedPassword, // Salva a senha hasheada
      age,
      weight,
      height,
      goal,
      availability,
    });

    // 6. Salvar o usuário no banco de dados
    await newUser.save();

    // 7. Responder com sucesso (sem enviar a senha)
    // Poderíamos enviar o usuário criado (sem a senha) ou apenas uma mensagem.
    // Para o JWT, faremos o login e geração do token separadamente.
    res.status(201).json({
      message: 'Usuário registrado com sucesso!',
      // Opcional: enviar alguns dados do usuário (sem a senha!)
      // user: {
      //   id: newUser._id,
      //   username: newUser.username,
      //   email: newUser.email
      // }
    });

  } catch (error) {
    // Tratar erros de validação do Mongoose ou outros erros
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({ message: messages.join('. ') });
    }
    console.error('Erro no registro:', error);
    res.status(500).json({ message: 'Erro interno do servidor ao registrar usuário.' });
  }
};

// A função de login virá aqui depois