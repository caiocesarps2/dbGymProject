import SignUpScreen from '@/screens/signUp/signUp'; 


export default SignUpScreen;