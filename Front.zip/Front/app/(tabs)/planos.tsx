// app/(tabs)/planos.tsx
import SubscriptionPlansScreen from '@/screens/plans/SubscriptionPlansScreen'; // Ajuste o caminho!
// Se `screens` está na raiz: import SubscriptionPlansScreen from '../../screens/plans/SubscriptionPlansScreen';
// Ou com alias: import SubscriptionPlansScreen from '@/screens/plans/SubscriptionPlansScreen';

export default SubscriptionPlansScreen;